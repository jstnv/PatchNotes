## Explicit fresh-Studio recipe or source-pinned simulation Studio checkpoint.
extends SceneTree
const Session := preload("res://scripts/simulation/campaign_session.gd")
const Replay := preload("res://scripts/simulation/development_replay.gd")

func _initialize() -> void:
	await process_frame
	var recipe_path := OS.get_environment("PN_CAMPAIGN_RECIPE")
	var checkpoint_path := OS.get_environment("PN_CAMPAIGN_CHECKPOINT")
	var tape_path := OS.get_environment("PN_CAMPAIGN_TAPE")
	var output := OS.get_environment("PN_CARD_FRAME_OUTPUT")
	for argument in OS.get_cmdline_user_args():
		var pair := argument.trim_prefix("--").split("=",true,1)
		if pair.size() != 2: continue
		if pair[0] == "recipe": recipe_path = pair[1]
		if pair[0] == "checkpoint": checkpoint_path = pair[1]
		if pair[0] == "tape": tape_path = pair[1]
		if pair[0] == "output": output = pair[1]
	if recipe_path.is_empty() == checkpoint_path.is_empty() or tape_path.is_empty():
		print("Usage: -- (--recipe=<fresh-studio.json> | --checkpoint=<studio.json>) --tape=<campaign-tape.json> --output=<report.json>")
		quit(2)
		return
	var session: RefCounted
	if not recipe_path.is_empty():
		session = create_fresh_session(JSON.parse_string(FileAccess.get_file_as_string(recipe_path)),root.get_node("CardDatabase"))
	else:
		var envelope: Variant = JSON.parse_string(FileAccess.get_file_as_string(checkpoint_path))
		var snapshots := PrimitiveSnapshotDatabase.new()
		if envelope is Dictionary and snapshots.load_ledgers():
			var restored := Session.new()
			if restored.restore_checkpoint(envelope,root.get_node("CardDatabase").get_development_catalog(),snapshots): session = restored
	var report: Dictionary = {"ok":false,"error":"Invalid campaign recipe or checkpoint"}
	if session != null: report = Replay.replay(session,Replay.load_tape(tape_path))
	if not output.is_empty(): FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print(JSON.stringify(report))
	quit(0 if report.ok else 1)

static func create_fresh_session(recipe: Variant, database: Node) -> RefCounted:
	if not recipe is Dictionary or recipe.get("schema_version") != 1: return null
	for field in ["studio_id","studio_name","specialty","seed"]:
		if not recipe.get(field) is String or recipe[field].is_empty(): return null
	if not recipe.seed.is_valid_int() or int(recipe.seed) < 0 or int(recipe.seed) > ProjectState.MAX_SIGNED_INT-RunRandom.STREAMS.size() or not recipe.get("traits") is Array: return null
	var traits: Array[StringName] = []
	for id: Variant in recipe.traits:
		if not id is String: return null
		traits.append(StringName(id))
	var run := RunState.new()
	run.initialize_cash(0)
	if not run.create_studio_with_traits(recipe.studio_name,StringName(recipe.specialty),traits): return null
	# Replace generated identities consistently, including education-debt opening
	# records. This is deterministic fixture bootstrap, not a save migration.
	var generated := String(run._bank_run_id)
	var stable := String(recipe.studio_id)
	run._studio_finance = _replace_identity(run._studio_finance,generated,stable)
	run._bank_run_id = StringName(stable)
	run._employees = EmployeeRoster.create(StringName(stable))
	for id in RunRandom.STREAMS: run.random_streams.stream(id).seed = int(recipe.seed)+RunRandom.STREAMS.find(id)
	var snapshots := PrimitiveSnapshotDatabase.new()
	if not snapshots.load_ledgers(): return null
	var session := Session.new()
	return session if session.initialize(run,database.get_development_catalog(),snapshots) else null

static func _replace_identity(value: Variant, old: String, replacement: String) -> Variant:
	if value is StringName: return StringName(String(value).replace(old,replacement))
	if value is String: return value.replace(old,replacement)
	if value is Array:
		var result: Array = value.duplicate(true)
		for index in range(result.size()): result[index] = _replace_identity(result[index],old,replacement)
		return result
	if value is Dictionary:
		var result: Dictionary = {}
		for key in value: result[_replace_identity(key,old,replacement)] = _replace_identity(value[key],old,replacement)
		return result
	return value
